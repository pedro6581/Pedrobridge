

# Pedrobridge
ㅤ
ㅤ
## 🌍 PT-BR

Resource adaptada por Pedro Scripts para conectar scripts às frameworks e dependências,
permitindo a integração com resources e frameworks externas.


## 📌 Instalação:

1. Coloque a pasta `Pedrobridge` na pasta `resources` do seu servidor.
2. Abra seu `server.cfg` e adicione `ensure Pedrobridge` antes dos scripts que usam o bridge.
3. Configure framework, idioma e inventário no arquivo `config.lua`.

## Compatibilidade

Todos os eventos, callbacks, comandos, logs e nomes internos usam `Pedrobridge`. O export principal continua sendo `GetBridge`.

Para usar o bridge em outro script:

```lua
local Bridge = exports["Pedrobridge"]:GetBridge()
```


## ⚙️ Frameworks suportadas

- vRP
- vRPex
- Creative (V5, V6, Network e Enchanted)
- Esx
- QBcore
- Qbox
